const http = require('http')

const coins = require("./estados.json")

const server = http.createServer((req, res) => {
    res.setHeader("Content-Type", "application/json")
    res.write(JSON.stringify(coins))

    res.end()
})

server.listen(8000, () => console.log("Servidor rodando na porta 4000"))